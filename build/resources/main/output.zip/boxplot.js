// append the svg object to the body of the page
function createBoxplot(target, data) {
  var margin = {top: 10, right: 20, bottom: 20, left: 60},
      svgWidth = 300 - margin.left - margin.right,
      svgHeight = 300 - margin.top - margin.bottom;
  let svg = d3.select(target)
  .append("svg")
  .attr("width", svgWidth + margin.left + margin.right)
  .attr("height", svgHeight + margin.top + margin.bottom)
  .append("g")
  .attr("transform",
      "translate(" + margin.left + "," + margin.top + ")");

  // create dummy data
  let q1 = data.q1;
  let median = data.median;
  let q3 = data.q3;
  let min = data.min;
  let max = data.max;

  // Show the Y scale
  let y = d3.scaleLinear()
  .domain([0,1.1 * q3])
  .range([svgHeight, 0]);
  svg.call(d3.axisLeft(y).tickFormat(function(d) { return d3.format(".3~s")(d) + "s"; }));

  // a few features for the box
  let center = 120;
  let boxWidth = 50;

// Show the main vertical line
  svg
  .append("line")
  .attr("x1", center)
  .attr("x2", center)
  .attr("y1", y(min) )
  .attr("y2", y(max) )
  .attr("stroke", "black");

// Show the box
  svg
  .append("rect")
  .attr("x", center - boxWidth/2)
  .attr("y", y(q3) )
  .attr("height", (y(q1)-y(q3)) )
  .attr("width", boxWidth )
  .attr("stroke", "black")
  .style("fill", "#7FAD9B");

  // show median, min and max horizontal lines
  svg
  .selectAll("toto")
  .data([min, median, max])
  .enter()
  .append("line")
  .attr("x1", center-boxWidth/2)
  .attr("x2", center+boxWidth/2)
  .attr("y1", function(d){ return(y(d))} )
  .attr("y2", function(d){ return(y(d))} )
  .attr("stroke", "black");
}
